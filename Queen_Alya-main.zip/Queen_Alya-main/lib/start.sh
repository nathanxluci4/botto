while true
do
echo "Starting QUEEN ALYA!"
node .
done
